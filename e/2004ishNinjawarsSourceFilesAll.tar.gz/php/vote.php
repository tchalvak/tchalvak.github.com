<?php
session_start();
$private    = false;
$alive      = false;
$quickstat  = false;
$page_title = "Vote for NinjaWars";

include "interface/header.php";
?>

<span class="brownHeading">Vote for Ninja Wars</span>

<p>
<a href="http://www.topwebgames.com/in.asp?id=1029" target="_blank">Vote for Ninja Wars on Top Web Games</a>

<br /><br />

<a href="http://www.gamesites200.com/mpog/vote.php?id=245" target="_blank"><img src="http://www.gamesites200.com/mpog/vote.gif" alt="Paid and Free MMORPG & MPOG" /></a>

<br /><br />

<a href="http://www.worldonlinegames.com/index.php?page=8&gid=107" target="_blank"><img src="http://worldonlinegames.com/images/vote.gif" alt="Vote for Ninja Wars" /></a>

<br /><br />

<a href="http://www.apexwebgaming.com/in.php?id=39" target="_blank">Click Here To Vote For Us At Apex Web Gaming</a>
<br /><br />

<script type="text/javascript" src="http://www.apexwebgaming.com/current_stats.php?id=39"></script>

<br />

<hr />
</p>

<?php
include "interface/footer.php";
?>
