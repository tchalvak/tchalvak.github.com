<html>
<head><title>PHP Testing</title></head>

<body>
<font color="red">PHP:</font>
<p>
<?php
echo ("Location: $PHP_SELF");
echo ("<p>");
$teststring = "Testword";
echo ("$teststring");


//Unused options:
// Gobbledey gook tech stuff: phpinfo();
/*
Locations of tutorial and testing page:
http://hotwired.lycos.com/webmonkey/01/48/index2a_page4.html?tw=programming
http://www.geneseo.edu/ror1/e/php/admin/testing.php

*/

?>

</body>
</html>

