<?php

// ************************************
// ********** CLASS FUNCTIONS *********
// ************************************

function setClass($who,$new_class)
{
  global $sql;

  $sql->Update("UPDATE players SET class = '$new_class' WHERE uname = '$who'");

  if ($who == $_SESSION['username'])
    {
      $_SESSION['class'] = $new_class;
    }

  return $new_class;
}

function getClass($who)
{
  global $sql;

  $class = $sql->QueryItem("SELECT class FROM players WHERE uname = '$who'");

  if ($who == $_SESSION['username'])
    {
      $_SESSION['class'] = $class;
    }

  return $class;
}

// ************************************
// ************************************



// ************************************
// ********* HEALTH FUNCTIONS *********
// ************************************

function setHealth($who,$new_health)
{
  global $sql;

  $sql->Update("UPDATE players SET health = '$new_health' WHERE uname = '$who'");
  
  if ($who == $_SESSION['username'])
    {
      $_SESSION['health'] = $new_health;
    }

  return $new_health;
}

function getHealth($who)
{
  global $sql;

  $health = $sql->QueryItem("SELECT health FROM players WHERE uname = '$who'");

  if ($who == $_SESSION['username'])
    {
      $_SESSION['health'] = $health;
    }
  
  return $health;
}

function changeHealth($who,$amount)
{
  if (abs($amount)>0)
    {
      global $sql;
      
      $sql->Update("UPDATE players SET health = health + ".
		   "CASE WHEN health+$amount < 0 THEN health*(-1) ELSE $amount END ".
		   "WHERE uname  = '$who'");
      
      $new_health = getHealth($who);
      
      return $new_health;
    }
  else
    {
      return getHealth($who);
    }
}

function addHealth($who,$amount)
{
  return changeHealth($who,$amount);
}

function subtractHealth($who,$amount)
{
  return changeHealth($who,((-1)*$amount));
}

// ************************************
// ************************************



// ************************************
// ********** GOLD FUNCTIONS **********
// ************************************

function setGold($who,$new_gold)
{
  global $sql;

  $sql->Update("UPDATE players SET gold = $new_gold WHERE uname = '$who'");

  return $new_gold;
}

function getGold($who)
{
  global $sql;

  $gold = $sql->QueryItem("SELECT gold FROM players WHERE uname = '$who'");

  if ($who == $_SESSION['username'])
    {
      $_SESSION['gold'] = $gold;
    }

  return $gold;
}

function changeGold($who,$amount)
{
  if (abs($amount) >  0)
    {
      global $sql;
      
      $sql->Update("UPDATE players SET gold = gold + ".
		   "CASE WHEN gold+$amount < 0 THEN gold*(-1) ELSE $amount END ".
		   "WHERE uname = '$who'");
      
      $new_gold = getGold($who);
      
      return $new_gold;
    }
  else
    {
      return getGold($who);
    }
}

function addGold($who,$amount)
{
  return changeGold($who,$amount);
}

function subtractGold($who,$amount)
{
  return changeGold($who,((-1)*$amount));
}

// ************************************
// ************************************



// ************************************
// ********** TURNS FUNCTIONS *********
// ************************************

function setTurns($who,$new_turns)
{
  global $sql;

  $sql->Update("UPDATE players SET turns = $new_turns WHERE uname = '$who'");

  if ($who == $_SESSION['username'])
    {
      $_SESSION['turns'] = $new_turns;
    }

  return $new_turns;
}

function getTurns($who)
{
  global $sql;

  $turns = $sql->QueryItem("SELECT turns FROM players WHERE uname = '$who'");

  if ($who == $_SESSION['username'])
    {
      $_SESSION['turns'] = $turns;
    }

  return $turns;
}

function changeTurns($who,$amount)
{
  if (abs($amount) > 0)
    {
      global $sql;
      
      $sql->Update("UPDATE players SET turns = turns + ".
		   "CASE WHEN turns+$amount < 0 THEN turns*(-1) ELSE $amount END ".
		   "WHERE uname  = '$who'");
      
      $new_turns = getTurns($who);
      
      return $new_turns;
    }
  else
    {
      return getTurns($who);
    }
}

function addTurns($who,$amount)
{
  return changeTurns($who,$amount);
}

function subtractTurns($who,$amount)
{
  return changeTurns($who,((-1)*$amount));
}

// ************************************
// ************************************



// ************************************
// ********** KILLS FUNCTIONS *********
// ************************************

function setKills($who,$new_kills)
{
  global $sql;

  $sql->Update("UPDATE players SET kills = $new_kills WHERE uname = '$who'");

  if ($who == $_SESSION['username'])
    {
      $_SESSION['kills'] = $new_kills;
    }

  return $new_kills;
}

function getKills($who)
{
  global $sql;

  $kills = $sql->QueryItem("SELECT kills FROM players WHERE uname = '$who'");

  if ($who == $_SESSION['username'])
    {
      $_SESSION['kills'] = $kills;
    }

  return $kills;
}

function changeKills($who,$amount)
{
  if (abs($amount) > 0)
    {
      global $sql;
      
      $sql->Update("UPDATE players SET kills = kills + ".
		   "CASE WHEN kills+$amount < 0 THEN kills*(-1) ELSE $amount END ".
		   "WHERE uname  = '$who'");
      
      $new_kills = getKills($who);
      
      return $new_kills;
    }
  else
    {
      return getKills($who);
    }
}

function addKills($who,$amount)
{
  return changeKills($who,$amount);
}

function subtractKills($who,$amount)
{
  return changeKills($who,((-1)*$amount));
}

// ************************************
// ************************************



// ************************************
// ********** LEVEL FUNCTIONS *********
// ************************************

function setLevel($who,$new_level)
{
  global $sql;

  $sql->Update("UPDATE players SET level = $new_level WHERE uname = '$who'");

  if ($who == $_SESSION['username'])
    {
      $_SESSION['level'] = $new_level;
    }

  return $new_level;
}

function getLevel($who)
{
  global $sql;

  $level = $sql->QueryItem("SELECT level FROM players WHERE uname = '$who'");

  if ($who == $_SESSION['username'])
    {
      $_SESSION['level'] = $level;
    }

  return $level;
}

function changeLevel($who,$amount)
{
  if (abs($amount) > 0)
    {
      global $sql;
      
      $sql->Update("UPDATE players SET level = level+$amount WHERE uname = '$who'");
      
      $new_level = getLevel($who);
      
      return $new_level;
    }
  else
    {
      return getLevel($who);
    }
}

function addLevel($who,$amount)
{
  return changeLevel($who,$amount);
}

function subtractLevel($who,$amount)
{
  return changeLevel($who,((-1)*$amount));
}

// ************************************
// ************************************



// ************************************
// ********* STATUS FUNCTIONS *********
// ************************************

define("STEALTH",1);
define("POISON",2);
define("FROZEN",4);
define("CLASS_STATE",8);
define("SKILL_1",16);
define("SKILL_2",32);
$status_array;

function setStatus($who,$what)
{
  global $sql;
  
  $sql->Update("UPDATE players SET status = $what WHERE uname = '$who'");

  if ($who == $_SESSION['username'])
    {
      $_SESSION['status'] = $what;

      if ($what == 0)
	{
	  echo "<br />You have returned to normal.<br />\n";
	}
      else if ($what == 1)
	{
	  echo "<br />You has been poisoned.<br />\n";
	}
      else if ($what == 2)
	{
	  echo "<br />You are now stealthed.<br />\n";
	}
    }

  return $what;
}

function getStatus($who)
{
  global $sql,$status_array;

  $status = $sql->QueryItem("SELECT status FROM players WHERE uname = '$who'");

  if ($who == $_SESSION['username'])
    {
      $_SESSION['status'] = $status;
    }

  $status_array['Stealth']    = ($status&STEALTH     ? 1 : 0);
  $status_array['Poison']     = ($status&POISON      ? 1 : 0);
  $status_array['Frozen']     = ($status&FROZEN      ? 1 : 0);
  $status_array['ClassState'] = ($status&CLASS_STATE ? 1 : 0);
  $status_array['Skill1']     = ($status&SKILL_1     ? 1 : 0);
  $status_array['Skill2']     = ($status&SKILL_2     ? 1 : 0);

  return $status_array;
}

function addStatus($who,$what)
{
  global $sql;

  $status = $sql->QueryItem("SELECT status FROM players WHERE uname = '$who'");

  if ($what < 0)
    {
      return subtractStatus($who,abs($what));
    }

  if (!($status&$what))
    {
      $sql->Update("UPDATE players SET status = status+$what WHERE uname = '$who'");
      
      if ($who == $_SESSION['username'])
	{
	  $_SESSION['status']+=$what;
	}
    }
      
      return getStatus($who);
}

function subtractStatus($who,$what)
{
  global $sql;

  $status = $sql->QueryItem("SELECT status FROM players WHERE uname = '$who'");

  if ($status&$what)
    {
      $sql->Update("UPDATE players SET status = status-($status&$what) WHERE uname = '$who'");
      
      if ($who == $_SESSION['username'])
	{
	  $_SESSION['status']-=($status&$what);
	}
    }
      
      return getStatus($who);
}

// ************************************
// ************************************



// ************************************
// ********* STRENGTH FUNCTIONS *******
// ************************************

function setStrength($who,$new_strength)
{
  global $sql;

  $sql->Update("UPDATE players SET strength = $new_strength WHERE uname = '$who'");

  if ($who == $_SESSION['username'])
    {
      $_SESSION['strength'] = $new_strength;
    }

  return $new_strength;
}

function getStrength($who)
{
  global $sql;

  $strength = $sql->QueryItem("SELECT strength FROM players WHERE uname = '$who'");

  if ($who == $_SESSION['username'])
    {
      $_SESSION['strength'] = $strength;
    }

  return $strength;
}

function changeStrength($who,$amount)
{
  if (abs($amount) > 0)
    {
      global $sql;
      
      $sql->Update("UPDATE players SET strength = strength+$amount WHERE uname = '$who'");
      
      $new_strength = getStrength($who);
      
      return $new_strength;
    }
  else
    {
      return getStrength($who);
    }
}

function addStrength($who,$amount)
{
  return changeStrength($who,$amount);
}

function subtractStrength($who,$amount)
{
  return changeStrength($who,((-1)*$amount));
}

// ************************************
// ************************************



// ************************************
// ********* BOUNTY FUNCTIONS *********
// ************************************

function setBounty($who,$new_bounty)
{
  global $sql;

  $sql->Update("UPDATE players SET bounty = $new_bounty WHERE uname = '$who'");

  if ($who == $_SESSION['username'])
    {
      $_SESSION['bounty'] = $new_bounty;
    }

  return $new_bounty;
}

function getBounty($who)
{
  global $sql;

  $bounty = $sql->QueryItem("SELECT bounty FROM players WHERE uname = '$who'");

  if ($who == $_SESSION['username'])
    {
      $_SESSION['bounty'] = $bounty;
    }

  return $bounty;
}

function changeBounty($who,$amount)
{
  if (abs($amount) > 0)
    {
      global $sql;
      
      $sql->Update("UPDATE players SET bounty = bounty+".
		   "CASE WHEN bounty+$amount < 0 THEN bounty*(-1) ELSE $amount END ".
		   "WHERE uname  = '$who'");
      
      $new_bounty = getBounty($who);
      
      return $new_bounty;
    }
  else
    {
      return getBounty($who);
    }
}

function addBounty($who,$amount)
{
  return changeBounty($who,$amount);
}

function subtractBounty($who,$amount)
{
  return changeBounty($who,((-1)*$amount));
}

function rewardBounty($bounty_to,$bounty_on)
{
  global $sql;

  $bounty = getBounty($bounty_on);

  setBounty($bounty_on,0);

  addGold($bounty_to,$bounty);

  return $bounty;
}

// ************************************
// ************************************



// ************************************
// ********** CLAN FUNCTIONS **********
// ************************************

function setClan($who,$clan_name)
{
  global $sql;

  $clan_long_name = $sql->QueryItem("SELECT clan_long_name FROM players WHERE clan = '$clan_name' LIMIT 1");

  $sql->Update("UPDATE players SET clan = '$clan_name', clan_long_name = '$clan_long_name' WHERE uname = '$who'");

  if ($who == $_SESSION['username'])
    {
      $_SESSION['clan'] = $clan_name;
    }
  
  return $clan_name;
}

function setClanLongName($who,$clan_long_name)
{
  global $sql;
  
  $sql->Update("UPDATE players SET clan_long_name = '$clan_long_name' WHERE uname = '$who'");

  return $clan_long_name;
}

function getClan($who)
{
  global $sql;

  $clan = $sql->QueryItem("SELECT clan FROM players WHERE uname = '$who'");

  if ($who == $_SESSION['username'])
    {
      $_SESSION['clan'] = $clan;
    }

  return $clan;
}

function getClanLongName($who)
{
  global $sql;

  $clan_long_name = $sql->QueryItem("SELECT clan_long_name FROM players WHERE uname = '$who'");

  return $clan_long_name;
}

function kick($who)
{
  global $today;

  $clan_long_name = getClanLongName($who);
  if (!$clan_long_name)
    {
      $clan_long_name = getClan($who)."'s clan";
    }

  setClan($who,"");
  setClanLongName($who,"");

  $msg = "You have been kicked out of $clan_long_name by ".$_SESSION['username']." on $today.";

  sendMessage($_SESSION['username'],$who,$msg);
}

function disbandClan($clan_name)
{
  global $sql;

  $_SESSION['clan']="";
  $sql->QueryRow("SELECT uname FROM players WHERE clan = '$clan_name'");
  $row = $sql->data;
  
  $message = "Your leader has disbanded your clan. You are alone again.";
  
  for ($i = 0; $i < $sql->rows; $i++)
    {
      $sql->Fetch($i);
      $name = $sql->data[0];
      
      sendMessage($clan_name,$name,$message);
    }
  
  $sql->Update("UPDATE players SET clan = '', clan_long_name = '' WHERE clan = '$clan_name'");
}

// ************************************
// ************************************

function sendMessage($from,$to,$msg)
{
  global $sql;

  $sql->Insert("INSERT INTO mail VALUES (0,'$from','$to','$msg')");
}



// *** NEED CLAN FUNCTIONS ***
// *** NEED SIGNUP/LOGIN FUNCTIONS ***
// *** NEED WORK FUNCTIONS ***
// *** NEED CASINO FUNCTIONS ***
// *** NEED SHRINE FUNCTIONS ***
// *** NEED COMBAT FUNCTIONS ***
// *** NEED INVENTORY FUNCTIONS ***
// *** NEED MAIL FUNCTIONS ***
// *** NEED DOJO FUNCTIONS ***

function kill($killer,$victim,$how,$what)
{
  echo "$killer has killed $victim!<br />\n";

  global $sql,$today;

  setHealth($victim,0);
  subtractStatus($victim,STEALTH+POISON+FROZEN+CLASS_STATE);

  $kill_point = 1;
  $_killer    = $killer;

  if ($how == "combat")
    {
      $msg = "$killer has killed you in combat on $today";
      $gold_mod  = .2;

      if ($what == "duel")
	{
	  $msg = "$killer has killed you in a duel on $today";
	  $gold_mod = .25;
	}
      else if  ($what == "stealth")
	{
	  $msg = "A stealthed player has killed you in combat on $today";
	  $gold_mod = .1;
	  $kill_point = 0;
	  $_killer = "A stealthed player";
	}
    }
  else if ($how == "item")
    {
      $msg  = "$killer has killed you using $what on $today";
      $gold_mod = .15;
    }
  else if ($how == "skill")
    {
      $msg  = "$killer has killed you using $what on $today";
      $gold_mod = .15;
    }

  $gold_won = takeGold($victim,$killer,$gold_mod);
  $msg.=" and taken $gold_won gold.";

  if ($kill_point){addKills($killer,$kill_point);}

  sendMessage($_killer,$victim,$msg);
  sendMessage($victim,$killer,str_replace($_killer." has","You have",str_replace("you",$victim,$msg)));
}

function takeGold($from,$to,$mod)
{
  global $sql;

  $victim_gold = getGold($from);
  $gold_change = round($victim_gold * $mod);
  $gold_change = ($gold_change < 0 ? 0 : $gold_change);

  addGold($to,$gold_change);
  subtractGold($from,$gold_change);

  echo "$to has acquired $gold_change gold from $from.<br />\n";

  return $gold_change;
}
?>