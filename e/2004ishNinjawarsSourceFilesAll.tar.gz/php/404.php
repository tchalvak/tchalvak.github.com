<html>
<head>
<title>
Update In Progress
<!-- 404 Error Page Not Found -->
</title>
</head>
<body bgcolor="black"  text="white">

<span style="font-weight: bold;color: white;">Custom 404</span>

<p>
We are in the middle of an update. We should be done by 2:30pm EST. Please try back at that time.
</p>


<!--
<p>
Perhaps you have lost your way.
</p>

Return to <a href="/webgame/index.php">Main</a>.
-->

</body>
</html>
